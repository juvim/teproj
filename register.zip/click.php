<html>
<body>
click<a href="http://www.123contactform.com/form-3012371/My-Form">here for payment page</a>
</html>