	<div id="main">
			<div class="logo">
				<a href="#">PayItDesk</a>
			</div>
			<div class="hp">
				<a href="#">Contact Us:9158112399</a>
			</div>
	</div>
	<div id="nav">
		<ul>
			<li><img src="images/house.png" alt="home" style="width:30px;height: auto;"><a class="act" href="index.php">HOME</a></li>
			<li><img src="images/abus.png" alt="home" style="width:30px;height: auto;"><a href="a.php">ABOUT US</a></li>
			<li><img src="images/bill.png" alt="home" style="width:30px;height: auto;"><a href="services.php">SERVICES</a></li>
			<li><img src="images/thinking.png" alt="home" style="width:30px;height: auto;"><a href="qd.php">QUERY DESK</a></li>
			<li><img src="images/login.png" alt="home" style="width:30px;height: auto;"><a href="login.php">SIGNUP/REGISTER</a></li>

		</ul>
    </div>