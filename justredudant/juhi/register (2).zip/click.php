<html>
<body>
click<a href="payment.html">here for payment page</a>
</html>